export type GlRenderingContext = WebGL2RenderingContext;
