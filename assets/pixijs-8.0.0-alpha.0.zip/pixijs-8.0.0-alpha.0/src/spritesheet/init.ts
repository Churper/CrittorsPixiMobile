import { extensions } from '../extensions/Extensions';
import { spritesheetAsset } from './spritesheetAsset';

extensions.add(spritesheetAsset);
