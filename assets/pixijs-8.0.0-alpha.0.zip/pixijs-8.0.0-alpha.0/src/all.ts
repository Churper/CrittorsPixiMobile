import './app/init';
import './assets/init';
import './events/init';
import './spritesheet/init';
import './rendering/init';
